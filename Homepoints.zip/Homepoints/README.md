# ffxi-addons/homepoints  
Homepoints:  
Since the addition of Home Point warps was added, it was quickly figured out that you didn't actually need to unlock a Home Point crystal to be able to warp to it. This addon just 'unlocks' all Home Point warps, regardless of if you've unlocked them or not, including the non-existant Al Zahbi Home Point (do not warp there).

Commands:  
None. When you load it and talk to a homepoint, it will change the mask of the incomming packet to force it to display all homepoint warps. 

Misc:  
In the script near the top there is an option to allow you to set a desired homepoint to go to easily. You can do this by talking to a homepoint and exiting the menu (escape).   
  
Warnings:  
This addon unlocks the Al Zahbi homepoint warp. There is no homepoint there. If you attempt to warp there, you will get stuck and bad things will happen.