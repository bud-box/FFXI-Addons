# FFXIInteract
A small library to help automate dialogue interactions in FFXI.
