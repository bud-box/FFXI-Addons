-- Add items to existing profiles or create your own to sell groups of items using alias commands
local profiles = {}

-- //sellnpc powder
profiles['powder'] = S{
    'prize powder',
    'acheron shield',
    'wind crystal',
    'earth crystal',
    'lightning crystal',
    'voidsnapper',
    }

-- //sellnpc ore
profiles['ore'] = S{
    'acheron shield',
    'copper ore',
    'tin ore',
    }

-- //sellnpc junk
profiles['junk'] = S{
    'chestnut',
    'san d\'Or. carrot',
    }

return profiles
